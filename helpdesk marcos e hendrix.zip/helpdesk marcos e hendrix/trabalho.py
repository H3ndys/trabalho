# Explicação:

# Classe HelpdeskChatbot: Representa o chatbot do helpdesk. Contém métodos para resetar senha, desbloquear usuário, abrir chamado, consultar chamado e encerrar atendimento.

# Métodos:

# reset_senha(login): Simula o reset da senha para um determinado login.
# desbloquear_usuario(login): Simula o desbloqueio de um usuário para um determinado login.
# abrir_chamado(nome_computador, descricao_problema): Simula a abertura de um chamado para manutenção em um computador, gerando um número de chamado e uma data fictícia de atendimento.
# consultar_chamado(numero_chamado): Consulta um chamado pelo número, retornando o status e a data prevista de atendimento.
# encerrar_atendimento(): Encerra o atendimento.
# Função main():

# Inicia o chatbot.
# Apresenta opções para o usuário escolher.
# Chama os métodos apropriados com base na opção escolhida pelo usuário.

import datetime

class HelpdeskChatbot:
    def __init__(self):
        self.chamados = {}

    def reset_senha(self, login):
        # Simula o reset da senha
        return f"Senha do usuário {login} resetada com sucesso."

    def desbloquear_usuario(self, login):
        # Simula o desbloqueio do usuário
        return f"Usuário {login} desbloqueado com sucesso."

    def abrir_chamado(self, nome_computador, descricao_problema):
        # Simula a abertura de um chamado
        numero_chamado = len(self.chamados) + 1
        data_atendimento = datetime.date.today() + datetime.timedelta(days=3)  # Simula atendimento em 3 dias
        self.chamados[numero_chamado] = {"nome_computador": nome_computador,
                                          "descricao_problema": descricao_problema,
                                          "data_atendimento": data_atendimento}
        return f"Chamado aberto com sucesso. Número do chamado: {numero_chamado}. Data de atendimento: {data_atendimento}"

    def consultar_chamado(self, numero_chamado):
        if numero_chamado in self.chamados:
            data_atendimento = self.chamados[numero_chamado]["data_atendimento"]
            return f"Chamado em andamento. Data prevista de atendimento: {data_atendimento}"
        else:
            return "Chamado não encontrado."

    def encerrar_atendimento(self):
        return "Atendimento encerrado."

# Função principal do chatbot
def main():
    chatbot = HelpdeskChatbot()

    while True:
        print("Opções:")
        print("1. Reset de senha")
        print("2. Desbloquear usuário")
        print("3. Abrir chamado para manutenção")
        print("4. Consultar chamado")
        print("5. Encerrar atendimento")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            login = input("Informe o login: ")
            print(chatbot.reset_senha(login))

        elif opcao == "2":
            login = input("Informe o login: ")
            print(chatbot.desbloquear_usuario(login))

        elif opcao == "3":
            nome_computador = input("Nome do computador: ")
            descricao_problema = input("Descrição do problema: ")
            print(chatbot.abrir_chamado(nome_computador, descricao_problema))

        elif opcao == "4":
            numero_chamado = int(input("Número do chamado: "))
            print(chatbot.consultar_chamado(numero_chamado))

        elif opcao == "5":
            print(chatbot.encerrar_atendimento())
            break

        else:
            print("Opção inválida. Por favor, escolha uma opção válida.")

if __name__ == "__main__":
    main()
