import openai

# Chave de API do OpenAI
api_key = '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'

# Função para iniciar uma nova conversa
def start_conversation():
    print("Iniciando nova conversa...")
    return input("Digite o assunto para começar: ")

# Função para continuar a conversa com o GPT-3
def continue_conversation(prompt):
    response = openai.Completion.create(
        engine="text-davinci-003",  # Escolha do mecanismo de IA
        prompt=prompt,
        temperature=0.7,
        max_tokens=150
    )
    return response.choices[0].text.strip()

# Função principal do chatbot
def main():
    # Inicia a conversa
    topic = start_conversation()
    conversation_over = False

    while not conversation_over:
        # Obtém a entrada do usuário
        user_input = input("Você: ")

        # Verifica se o usuário quer iniciar um novo assunto
        if user_input.lower() == 'novo':
            topic = start_conversation()
        # Verifica se o usuário quer encerrar a conversa
        elif user_input.lower() == 'encerrar':
            conversation_over = True
            print("Conversa encerrada.")
        # Caso contrário, continua a conversa com base no assunto atual
        else:
            # Adiciona a entrada do usuário ao tópico atual
            topic += "\nUsuário: " + user_input
            # Obtém a resposta do GPT-3 com base no tópico atualizado
            response = continue_conversation(topic)
            # Exibe a resposta do GPT-3
            print("ChatGPT:", response)

if __name__ == "__main__":
    # Configura a chave de API do OpenAI
    openai.api_key = api_key
    # Inicia a conversa
    main()

